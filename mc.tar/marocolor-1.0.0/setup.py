from setuptools import setup, find_packages

setup(
    name="marocolor",
    version="1.0.0",
    packages=find_packages(),
    install_requires=['requests'],
    description="Enhanced color palette utilities for terminal UI",
    author="MarocoColor Dev",
    url="http://marocolor.net",
)
