# marocolor\nProfessional terminal color palette library.
